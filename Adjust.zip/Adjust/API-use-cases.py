download_url= "https://gist.githubusercontent.com/kotik/3baa5f53997cce85cc0336cb1256ba8b/raw/3c2a590b9fb3e9c415a99e56df3ddad5812b292f/dataset.csv"
import requests
target_csv_path = "nba_all_elo.csv"
response = requests.get(download_url)
response.raise_for_status()    # Check that the request was successful
with open(target_csv_path, "wb") as f:
    f.write(response.content)
print("Download ready.")
import pandas as pd
nba = pd.read_csv("nba_all_elo.csv")
print(nba.head())

import os
if os.path.exists("first.csv"):
    os.remove("first.csv")

# 1.Show the number of impressions and clicks that occurred before the 1st of June 2017, broken down by channel and country, sorted by clicks in descending order. Hint:
s=nba[['channel', 'country','impressions','clicks','date']].loc[nba['date'] < '2017-06-01'].sort_values('clicks',axis=0, ascending=False,)
s1=s.groupby('channel')['impressions','channel', 'country','clicks','date'].sum()
print(s1)
gfg_csv_data = s1.to_csv('first.csv', index = True)
print('\nCSV String:\n', gfg_csv_data)
print(nba['date'])


import os
if os.path.exists("second.csv"):
    os.remove("second.csv")


# 2.Show the number of installs that occurred in May of 2017 on iOS, broken down by date, sorted by date in ascending order.

s=nba[['installs','impressions','date']].loc[(nba['date'] >= '2017-05-01') & (nba['date'] <= '2017-06-01') & (nba['os'] <= 'ios')].sort_values('date',axis=0, ascending=True)           
s.groupby('date')['installs']
print(s,"sdfasdf")
gfg_csv_data = s.to_csv('second.csv', index = True)
print('\nCSV String:\n', gfg_csv_data)

import os
if os.path.exists("third.csv"):
    os.remove("third.csv")

# 3.Show revenue, earned on June 1, 2017 in US, broken down by operating system and sorted by revenue in descending order.
s=nba[['revenue', 'date','os']].loc[nba['date'] == '2017-06-01'].sort_values('revenue',axis=0, ascending=False,)           
s.groupby('os')['revenue','date']
print(s,"sdfasdf")
gfg_csv_data = s.to_csv('third.csv', index = True)
print('\nCSV String:\n', gfg_csv_data)

import os
if os.path.exists("fourth.csv"):
    os.remove("fourth.csv")


# 4.Show CPI and spend for Canada (CA) broken down by channel ordered by CPI in descending order. Please think carefully which is an appropriate aggregate function for CPI.
cpi=nba.iloc[:,7].div(nba.iloc[:,6])
nba['CPI']=cpi
s=nba[['spend','CPI']].loc[nba['date'] == '2017-06-01'].sort_values('CPI',axis=0, ascending=False,)           
s.groupby('CPI')['spend','CPI']
print(s,"sdfasdf")
gfg_csv_data = s.to_csv('fourth.csv', index = True)
print('\nCSV String:\n', gfg_csv_data)

