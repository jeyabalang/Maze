from flask import Flask, render_template
app = Flask(__name__)
import pandas

@app.route('/')
def display():
    return "Adjust Homepage"

@app.route('/first')
def first():
    filename = 'first.csv'
    data = pandas.read_csv(filename, header=0)
    stocklist = list(data.values)
    print(stocklist)
    return render_template('first.html', stocklist=stocklist)

@app.route('/second')
def second():
    filename = 'second.csv'
    data = pandas.read_csv(filename, header=0)
    stocklist = list(data.values)
    print(stocklist)
    return render_template('second.html', stocklist=stocklist)


@app.route('/third')
def third():
    filename = 'third.csv'
    data = pandas.read_csv(filename, header=0)
    stocklist = list(data.values)
    print(stocklist)
    return render_template('third.html', stocklist=stocklist)

@app.route('/fourth')
def fourth():
    filename = 'fourth.csv'
    data = pandas.read_csv(filename, header=0)
    stocklist = list(data.values)
    print(stocklist)
    return render_template('fourth.html', stocklist=stocklist)

if __name__=='__main__':
    app.run()